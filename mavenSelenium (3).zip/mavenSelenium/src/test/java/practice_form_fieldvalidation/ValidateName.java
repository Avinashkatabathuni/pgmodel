package practice_form_fieldvalidation;
 
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
 
public class ValidateName {
	
	WebDriver driver;
	WebElement inputFieldName;
	WebElement errorLabelName;
 
  @BeforeClass
  public void beforeClass() {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\nkrishna.chowd\\selenium_workspace\\resources\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	  driver.get("https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php");
	  inputFieldName=driver.findElement(By.xpath("//input[@id='name']"));
	  
	  
  }
  
  @Test
  public void checkNumbers() {
	  inputFieldName.sendKeys("1");
	  inputFieldName.sendKeys(Keys.TAB);
	  try {
		  errorLabelName=driver.findElement(By.xpath("//*[@id='name-error']"));
		  //System.out.println(errorLabelName.getText());
		  System.out.println("Rejected");
	  }catch(Exception e) {
		 // System.out.println("Exception occured" +e);
		  System.out.println("Accepted");
		  //Reporter.log("Accepted bro!");
	  }
	
	
  }
 
}
 