package com.selenium.mavenSelenium;
 
import java.util.Arrays;
import java.util.List;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
 
public class S15_TableContents {
	WebDriver driver;
	
	 @BeforeClass
	  public void beforeClass() {
			driver=new ChromeDriver();
			driver.get("https://cosmocode.io/automation-practice-webtable/");
			
	  }
 
  @Test
  public void f() {
	  
 
	  //Getting all rows and storing in a list
	  List<WebElement> dataRows = driver.findElements(By.xpath("//table[@id='countries']//tbody/tr"));
	  
	  if (dataRows.size() >= 2) {
		  	WebElement secondRow = dataRows.get(1); // index 1 = second data row
		  	System.out.println("Second row Data: " + secondRow.getText());
	  } else {
		  	System.out.println("Table does not have two lines!! ");
	  }
  }
 
  @Test
public void basedOnCountryName() {
	  
 
	  //Getting all rows and storing in a list
	  List<WebElement> dataRows = driver.findElements(By.xpath("//table[@id='countries']//tbody/tr"));
	  String ExpectedCountryName="Angola";
	  boolean flag=false;
	  
	  for(WebElement eachRow:dataRows) {
		 String[] sentence=eachRow.getText().split(" ");
		 String retrivedCountryName=sentence[0];
		 //System.out.println("Retrived Country Name: "+retrivedCountryName);
		 if(retrivedCountryName.equals(ExpectedCountryName)) {
			 flag=true;
			 System.out.println("Expected country Name: "+ExpectedCountryName);
			 System.out.println("Retrived Country Name:"+ExpectedCountryName);
			 System.out.println(Arrays.toString(sentence));
		 }
	  }
	  if(!flag) {
		  System.out.println("Expected Country Name: "+ExpectedCountryName);
		  System.out.println("Expected Country details not exist");
	  }
  }
  
  @AfterClass
  public void afterClass() {
  }
 
}