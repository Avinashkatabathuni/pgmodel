
package com.selenium.mavenSelenium;

import java.time.Duration;
import java.time.LocalDateTime;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class S13_WaitTypes {

    // Run ALL
    WebDriver driver;

    @BeforeClass
    public void launchBrowser() {
        ChromeOptions options = new ChromeOptions();
        options.setPageLoadStrategy(PageLoadStrategy.NORMAL); // Default
        driver = new ChromeDriver(options);

        // PageLoadTimeout (read-only as of Selenium 4)
        Duration time = driver.manage().timeouts().getPageLoadTimeout();
        System.out.println("Default PageLoad Timeout: " + time);
        Reporter.log("Launched URL", true);
    }

    @AfterClass
    public void tearDown() {
        // driver.quit();
        System.out.println("Execution Completed");
    }

    // ---------------------------------------------------------------------
    // Test 1: Demonstrate element not interactable when no wait / wrong timing
    // ---------------------------------------------------------------------
    @Test(enabled = true)
    public void a_fails() {
        driver.get("https://www.selenium.dev/selenium/web/dynamic.html");

        driver.findElement(By.id("adder")).click();   // adds a box
        driver.findElement(By.id("reveal")).click();  // reveals the textbox

        WebElement revealed = driver.findElement(By.id("revealed"));
        // revealed.sendKeys("Displayed"); // throws error: element not interactable

        System.out.println("Text box isDisplayed: " + revealed.isDisplayed());
    }

    // ---------------------------------------------------------------------
    // Test 2: Sleep-based wait 
    // ---------------------------------------------------------------------
    @Test(enabled = false)
    public void b_sleep() throws InterruptedException {
        driver.get("https://www.selenium.dev/selenium/web/dynamic.html");

        driver.findElement(By.id("adder")).click();
        //driver.findElement(By.id("reveal")).click();

        // Set some simple timings (for demo)
        System.out.println(LocalDateTime.now());
        Thread.sleep(2000);
        System.out.println("Waiting...");
        System.out.println(LocalDateTime.now());

        WebElement added = driver.findElement(By.id("box0"));
        Assert.assertEquals("redbox", added.getDomAttribute("class"));
        Assert.assertEquals("Class ", added.getDomAttribute("class"));
    }

    // ---------------------------------------------------------------------
    // Test 3: Implicit wait
    // ---------------------------------------------------------------------
    @Test
    public void c_implicit() {
        Duration timeout = driver.manage().timeouts().getImplicitWaitTimeout();
        System.out.println("Default implicit wait timeout: " + timeout);

        // Set implicit wait timeout
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));

        driver.get("https://www.selenium.dev/selenium/web/dynamic.html"); // Load page
        driver.findElement(By.id("adder")).click(); // click on element

        WebElement added = driver.findElement(By.id("box0"));
        // In dynamic.html, the 'box' div gets class and style as it appears
        Assert.assertEquals("redbox", added.getDomAttribute("class"));
        System.out.println("Added box " + added.getDomAttribute("style"));
    }

    // ---------------------------------------------------------------------
    // Test 4: Explicit wait (basic)
    // ---------------------------------------------------------------------
    @Test(enabled = true)
    public void d_explicit() {
        driver.get("https://www.selenium.dev/selenium/web/dynamic.html");

        driver.findElement(By.id("reveal")).click();

        WebElement revealed = driver.findElement(By.id("revealed"));

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2));
        // Wait until visible
        wait.until(ExpectedConditions.visibilityOf(revealed));

        // Or: wait until element becomes clickable
        // wait.until(ExpectedConditions.elementToBeClickable(By.id("revealed")));

        revealed.sendKeys("Displayed");
    }

    // ---------------------------------------------------------------------
    // Test 5: Explicit wait with options (timeout, polling, ignored exceptions)
    // ---------------------------------------------------------------------
    @Test(enabled = true)
    public void e_explicitWithOptions() {
        driver.get("https://www.selenium.dev/selenium/web/dynamic.html");

        driver.findElement(By.id("reveal")).click();

        WebElement revealed = driver.findElement(By.id("revealed"));

        Wait<WebDriver> fwait = new FluentWait<>(driver)
        		.withTimeout(Duration.ofSeconds(2))
        		.pollingEvery(Duration.ofMillis(300))
        		.ignoring(ElementNotInteractableException.class);
        

        fwait.until(ExpectedConditions.visibilityOf(revealed));
        revealed.sendKeys("Displayed");
    }
}
