package com.selenium.mavenSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GoogleFormScript {
	public static void main(String[] args) {
		//WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://docs.google.com/forms/d/e/1FAIpQLSeymvPzvTExSkg28UpRu2dZSsS8cdw6xnJJDdK07KCc-th96w/viewform");
		
		//Fill Email Field using Full XPath
		WebElement email = driver.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div[2]/div/div[2]/div[1]/div/div[1]/div[2]/div[1]/div/div[1]/input"));
		email.sendKeys("2100032143cseh@gmail.com");
		
		//Fill HclMail Field using Full XPath
		WebElement Hclmail = driver.findElement(By.xpath("//*[@id=\"mG61Hd\"]/div[2]/div/div[2]/div[2]/div/div/div[2]/div/div[1]"));
		Hclmail.sendKeys("nkrishna.chowd@hcltech.com");
		
		//Fill Name Field using Full XPath
		WebElement name = driver.findElement(By.xpath("/html/body/div/div[2]/form/div[2]/div/div[2]/div[3]/div/div/div[2]/div/div[1]/div/div[1]/input"));
		name.sendKeys("N Krishna Chowdary Pathuri");
		
		//Fill Name Field using Full XPath
		WebElement sapid = driver.findElement(By.xpath("/html/body/div/div[2]/form/div[2]/div/div[2]/div[4]/div/div/div[2]/div/div[1]/div/div[1]/input"));
		sapid.sendKeys("52357018");
		
		//Fill ODC Field using Full XPath
		WebElement odc = driver.findElement(By.xpath("/html/body/div/div[2]/form/div[2]/div/div[2]/div[9]/div/div/div[2]/div/div[1]/div/div[1]/input"));
		odc.sendKeys("LGF09");
		
		//Fill ODC Field using Full XPath
		//WebElement loc = driver.findElement(By.xpath("//*[@id=\"i25\"]/div[3]/div"));
		//loc.click();
		

		//Fill Name Field using Full XPath
		//WebElement location = driver.findElement(By.cssSelector("#i25 > div.vd3tt > div"));
		//WebElement location = driver.findElement(By.xpath("//*[@id=\"i25\"]/div[3]/div"));
		
		
	}

}
