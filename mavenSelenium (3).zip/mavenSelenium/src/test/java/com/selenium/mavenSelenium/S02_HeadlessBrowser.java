package com.selenium.mavenSelenium;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
 
public class S02_HeadlessBrowser {
 
	public static void main(String[] args) {
//		ChromeOptions c=new ChromeOptions();
//		c.addArguments("--headless=new");
//		WebDriver d = new ChromeDriver(options);
 
		WebDriver driver = new HtmlUnitDriver();
		driver.get("https://www.abhibus.com/");
		System.out.println("title:" + driver.getTitle());
		driver.close();
 
	}
 
}