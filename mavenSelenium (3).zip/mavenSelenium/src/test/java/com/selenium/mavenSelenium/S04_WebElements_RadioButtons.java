//Create a List Element for Radio Button and Print the size of that particular element
//Create a List Element for Radio Buttons and print the Option text of that radio button element

package com.selenium.mavenSelenium;

import java.util.List;

//import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class S04_WebElements_RadioButtons {

	public static void main(String[] args) {
		
		WebDriver driver = new ChromeDriver();
		// Link: https://demoqa.com/automation-practice-form
		//Radio Buttons
		driver.get("https://demoqa.com/automation-practice-form");
		//#gender-radio-1
		//Create a List Element for Radio Button and Print the size of that particular element
		List<WebElement> radioBtn = driver.findElements(By.cssSelector("input[type='radio']"));
		int rbsize = radioBtn.size();
		System.out.println("No of Radio Buttons: " + rbsize + "\n Displayed Radio Buttons: ");
		 //"//*[@id=\"practiceForm\"]/div[3]/div/div/div"
		
		//Create a List Element for Radio Buttons and print the Option text of that radio button element
		List<WebElement> radioBtnList = driver.findElements(By.xpath("//*[@id=\"genterWrapper\"]/div[2]"));
		for(int i=0; i<rbsize; i++) {
			System.out.println(i + ": " + radioBtnList.get(i).getText());
			if(radioBtnList.get(i).isSelected()) {
				System.out.println("Already Selected");
			}
			else {
				System.out.println("Not selected");
			}
			//Select Female
			radioBtn.get(2).click();
			
			driver.close();
		}
		
	}
}
