//Selecting dropdown element by XPath. Using Select statement here.
//Print the options of the Dropdown. Get List of Web Elements by Using Select -> getOptions()
//Looping through the options and printing Dropdown options
//Create a List element and print the selected element among the options
//Select option with Index 4


package com.selenium.mavenSelenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;


public class S05_SelectClass {

	public static void main(String[] args) {
		//Dropdown
		// Link: https://demoqa.com/select-menu
		
		//WebDriver driver = new ChromeDriver();
		
		System.setProperty("webdriver.edge.driver", "C:\\Users\\nkrishna.chowd\\selenium_workspace\\resources\\edgedriver_win64\\msedgedriver.exe");

		WebDriver driver;
		driver = new EdgeDriver();
		
		driver.get("https://demoqa.com/select-menu");
		
		//Selecting dropdown element by XPath
		//Using Select statement here.
		Select sel = new Select(driver.findElement(By.id("oldSelectMenu")));
		
		//Print the options of the Dropdown
		//Get List of Web Elements by Using Select -> getOptions()
		List<WebElement> list = sel.getOptions();
		
		
		//Looping through the options and printing Dropdown options
		System.out.println("The Dropdown Options are:");
		for(WebElement options : list)
			System.out.println(options.getText());
		

		//Create a List element and print the selected element among the options
		List<WebElement> lst = sel.getAllSelectedOptions();
		for(WebElement opt : lst)
		{
			System.out.println(opt.getText());
		}
		
		//Select option with Index 4
		sel.selectByIndex(4);
		
		
		//Close the driver
		driver.close();
		
	}
}
