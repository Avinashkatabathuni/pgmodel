/*
Script 6

Find and Click on 5 in Calculator keyboard using XPath
Find and Click on 4 in Calculator keyboard using Relative Locator: toleftOf()
Find and Click on 6 in Calculator keyboard using Relative Locator: toRightOf()
Find and Click on - in Calculator keyboard using Relative Locator: toRightOf()
Find and Click on 2 in Calculator keyboard using Relative Locator: below()
Find and Click on = in Calculator keyboard using XPath
Find and Click on Search Button in Calculator keyboard using ID
Find and Enter Data in Search Box in Calculator keyboard using Relative Locator: near()
*/


package com.selenium.mavenSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.locators.RelativeLocator;

public class s06_RelativeLocators {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.calculator.net/");
		
		//Find and Click on 5 in Calculator keyboard using XPath
		WebElement five = driver.findElement(By.xpath("//span[text()='5']"));
		five.click();
				
		//Find and Click on 4 in Calculator keyboard using Relative Locator: toleftOf() 
		WebElement four = driver.findElement(RelativeLocator.with(By.tagName("span")).toLeftOf(five));
		four.click();
		
		//Find and Click on 6 in Calculator keyboard using Relative Locator: toRightOf()
		WebElement six = driver.findElement(RelativeLocator.with(By.tagName("span")).toRightOf(five));
		six.click();
		
		//Find and Click on - in Calculator keyboard using Relative Locator: toRightOf()
		WebElement minus = driver.findElement(RelativeLocator.with(By.tagName("span")).toRightOf(six));
		minus.click();
		
		//Find and Click on 2 in Calculator keyboard using Relative Locator: below()
		WebElement two = driver.findElement(RelativeLocator.with(By.tagName("span")).below(five));
		two.click();
		
		//Find and Click on = in Calculator keyboard using XPath
		WebElement equals = driver.findElement(By.xpath("//span[text()='=']"));
		equals.click();
		
		//Find and Click on Search Button in Calculator keyboard using ID
		WebElement searchBtn = driver.findElement(By.id("bluebtn"));
		searchBtn.click();
		//Find and Enter Data in Search Box in Calculator keyboard using Relative Locator: near()
		WebElement searchTextBox = driver.findElement(RelativeLocator.with(By.tagName("input")).near(searchBtn));
		searchTextBox.sendKeys("loan");
		
		//Get List of Attributes using List
		/*
		 List<WebElement> elems =
		 driver.findElements(RelativeLocator.with(By.tagName("input")) .below(five) );
		 
		 for(WebElement button : elems) {
		 	System.out.println(button.getAttribute("value")); }
		 */
		
	}
}
