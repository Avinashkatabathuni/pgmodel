package com.selenium.mavenSelenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class S12_IFramesHandling {

	WebDriver driver = new ChromeDriver();
	
	@BeforeClass
	public void Launch() {
		driver.manage().window().maximize();
		driver.get("https://www.hyrtutorials.com/p/frames-practice.html");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		System.out.println("URL Launched");
	}
	
	@AfterClass
	public void close() {
		//driver.quit();
		System.out.println("Executed Successfully");
	}
	
	@Test
	public void a_SwitchToFrame() throws InterruptedException {
		driver.findElement(By.id("name")).sendKeys("Hello");

		//Frame 1
		
		driver.switchTo().frame(driver.findElement(By.id("frm1")));
		Select CourseDD = new Select(driver.findElement(By.id("course")));
		CourseDD.selectByVisibleText("Java");
		
		driver.switchTo().defaultContent();
		driver.findElement(By.id("name")).sendKeys("World");
		
		
		//Frame 3
		
		driver.findElement(By.id("name")).sendKeys("Frame3");
		driver.switchTo().frame(driver.findElement(By.id("frm3")));
		Select CourseDD1 = new Select(driver.findElement(By.id("course")));
		CourseDD1.selectByContainsVisibleText("Java");
		Thread.sleep(2000);
		driver.switchTo().parentFrame();
		driver.findElement(By.id("name")).clear();
		Thread.sleep(2000);
		driver.findElement(By.id("name")).sendKeys("Main WebPage");
		
	}
}
