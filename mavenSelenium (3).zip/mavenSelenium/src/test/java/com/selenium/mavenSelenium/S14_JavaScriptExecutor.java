package com.selenium.mavenSelenium;
 
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.openqa.selenium.chrome.ChromeDriver;
import java.time.Duration;
 
public class S14_JavaScriptExecutor 
{
	WebDriver driver;
  @BeforeClass
  public void setup() 
  {
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
}
  @Test
  public void JSExecutorCommands() throws InterruptedException
  {
	  // Casting WebDriver as JavaScriptExecutor
      JavascriptExecutor js = (JavascriptExecutor) driver;
      //Launching URL using JS
      js.executeScript("window.location = 'https://demoqa.com/text-box'");
      //Get height and width of webPage
      String height = js.executeScript("return window.innerHeight;").toString();
      String width = js.executeScript("return window.innerWidth;").toString();
      System.out.println("Height :"+ height +"\t width: "+ width);
      //Refresh Browser
      js.executeScript("history.go(0);");
      Reporter.log("Reloaded Page",true);
      //Get Current Url
      String url = js.executeScript("return document.URL;").toString();
      Reporter.log("Current Url : "+ url, true);
      //Get Current Domain
      String domain = js.executeScript("return document.domain;").toString();
      Reporter.log("Current domain :"+ domain, true);  
      //Get Current Title
      String title = js.executeScript("return document.title;").toString();
      Reporter.log("Page title :"+ title, true); 
     //Find Element By ID & enter text
      WebElement email = (WebElement) js.executeScript("return document.getElementById('userEmail');");
      email.sendKeys("abc@xyz.com");
      //Using CSS Selector
      WebElement name = (WebElement) js.executeScript("return document.querySelector('#userName');");
      name.sendKeys("Testing");
      //Using QuerySelectorAll – return label text
      WebElement label = (WebElement) js.executeScript("return document.querySelectorAll('label')[0]");
      System.out.println(label.getText());
      //Get attribute
      String sclassName = js.executeScript("return document.getElementById('userEmail').className;").toString();
      System.out.println("Class Name: " + sclassName);
      //Send Key using JS
      WebElement add = (WebElement) js.executeScript("return document.getElementById('userName');");
      js.executeScript("arguments[0].value='Automation testing batch';", add);
      //Get Value in textbox
      String text = (String) js.executeScript("return arguments[0].value;", add);
      System.out.println("Entered text is: " + text);
      //Get innerText
      String innertext = (String) js.executeScript("return arguments[0].innerText;", label);
      System.out.println("innerText is: " + innertext);
      //Scroll to bottom
      js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
      //Scroll into element
      js.executeScript("arguments[0].scrollIntoView(true);", name);
      Thread.sleep(2000);
      //Scroll by pixel
      js.executeScript("window.scrollBy(50,100)");
      Thread.sleep(2000);
      //Change style attribute
      js.executeScript("document.getElementById('submit').style.borderColor='red'");
      Thread.sleep(2000);
      //Change multiple style attributes
      String multipleStyles = "border:4px solid blue; background-color:yellow; color:red;";
      js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
              add, multipleStyles);
      Thread.sleep(2000);
      //Find total frames
      Long count = (Long) js.executeScript("return window.frames.length;");
      System.out.println("Total frames: " + count);
      //Trigger alert
      js.executeScript("alert('This is an alert triggered by JSExecutor!');");
      Thread.sleep(3000);
      Alert alert1 = driver.switchTo().alert();
      System.out.println(alert1.getText());
      alert1.dismiss();
  }

 
  @AfterClass
  public void closeBrowser() {
      //driver.quit();
      System.out.println("JavaScript Executor : Done");
  }
 
}