/*Mouse Actions- on elements

click(), contextClick(),RightClick, clickAndHold(),release(),doubleClick()

moveToElement(),HoverElement, dragAndDrop(a,b) 

with Offset:

moveToElement(element,X,Y), dragAndDropBy(element,X,Y)

*/

package com.selenium.mavenSelenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class S10_Mouse_Actions {

	WebDriver driver;
	//WebElement clickable = driver.findElement(By.id("clickable"));
	//WebElement hoverable = driver.findElement(By.id("hover"));
	@BeforeClass
	public void Launch() {
		driver = new ChromeDriver();
		driver.get("https://www.selenium.dev/selenium/web/mouse_interaction.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(300));
	}
	
	@AfterClass
	public void close() {
		//driver.quit();
		System.out.println("Execution completed");
	}
	
	
	//click()
	@Test
	public void a_leftClick() {
		WebElement clickable = driver.findElement(By.id("clickable"));
		new Actions(driver).click(clickable).perform();
		System.out.println("Page Loaded: " + driver.getTitle());
//		driver.navigate().back();
	}
	
	
	//contextClick()
	@Test 
	public void b_rightClick() {
		Actions right = new Actions(driver);
		WebElement clickable = driver.findElement(By.id("clickable"));
		right.contextClick(clickable); 
		right.build().perform();
		clickable.sendKeys("hello");
		System.out.println(driver.findElement(By.id("clickable")).getText());
		clickable.sendKeys(Keys.ESCAPE);
	}
	
	
	//doubleClick()
	@Test
	public void c_doubleClick() {
		WebElement clickable = driver.findElement(By.id("clickable"));		
		new Actions(driver).doubleClick(clickable).perform();
		System.out.println(driver.findElement(By.id("click-status")));
	}
	
	
	//moveToElement()
	@Test
	public void d_hovers() {
		WebElement hoverable = driver.findElement(By.id("hover"));
		new Actions(driver).moveToElement(hoverable).perform();
		System.out.println(driver.findElement(By.id("click-status")));
	}
	
	
	//clickAndHold()
	@Test
	public void e_clickAndHold() {
		WebElement clickable = driver.findElement(By.id("clickable"));
		new Actions(driver).clickAndHold().release().perform();
		System.out.println(driver.findElement(By.id("click-status")).getText());
	}
	
	
	//dragAndDrop()
	@Test
	public void f_dragsToElement() {
		WebElement draggable = driver.findElement(By.id("draggable"));
		WebElement droppable = driver.findElement(By.id("droppable"));
		new Actions(driver).dragAndDrop(draggable, droppable).perform();
		System.out.println("Drop Status: " + driver.findElement(By.id("drop-status")).getText());
	}
}
