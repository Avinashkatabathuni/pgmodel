package com.selenium.mavenSelenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class MockPractice {

    // 1. locateNonTextTypeElements:
    // Return <input> elements whose type is NOT "text" and are inside the <form>
    public static List<WebElement> locateNonTextTypeElements(WebDriver driver, String pageURL) {
        driver.get(pageURL);

        // Select all input elements inside form except type="text"
        return driver.findElements(By.xpath("//form//input[not(@type='text')]"));
    }

    // 2. locateContactElements:
    // Return <input> elements whose name begins with "contact" and are inside form
    public static List<WebElement> locateContactElements(WebDriver driver, String pageURL) {
        driver.get(pageURL);

        return driver.findElements(By.xpath("//form//input[starts-with(@name,'contact')]"));
    }

    // 3. locateSubmitElement:
    // Return the submit button (only one exists)
    public static WebElement locateSubmitElement(WebDriver driver, String pageURL) {
        driver.get(pageURL);

        ////*[@id="seleniumform"]/div[6]/button
        return driver.findElement(By.xpath("//form//button[@type='submit' or @type='Submit']"));
    }

    // 4. locateIdMissingElements:
    // Return <input> elements inside form that DO NOT have an id attribute
    public static List<WebElement> locateIdMissingElements(WebDriver driver, String pageURL) {
        driver.get(pageURL);

        // Select input with no id
        return driver.findElements(By.xpath("//form//input[not(@id)]"));
    }

    // -----------------------------
    // Added main method (no changes to your existing methods)
    // -----------------------------
    public static void main(String[] args) {
        // Optional: Use WebDriverManager if you have it in your pom.xml
        // io.github.bonigarcia.wdm.WebDriverManager.chromedriver().setup();

        WebDriver driver = new ChromeDriver();
        String pageURL = "https://www.lambdatest.com/selenium-playground/input-form-demo";

        try {
            // 1) Non-text type inputs inside form
            List<WebElement> nonTextInputs = locateNonTextTypeElements(driver, pageURL);
            System.out.println("Non-text <input> elements inside <form>: " + nonTextInputs.size());
            for (WebElement el : nonTextInputs) {
                System.out.printf(" - type=%s, name=%s, id=%s%n",
                        safeAttr(el, "type"), safeAttr(el, "name"), safeAttr(el, "id"));
            }

            // 2) Inputs whose name starts with 'contact' inside form
            List<WebElement> contactInputs = locateContactElements(driver, pageURL);
            System.out.println("\n<form> inputs with name starting 'contact': " + contactInputs.size());
            for (WebElement el : contactInputs) {
                System.out.printf(" - name=%s, type=%s, id=%s%n",
                        safeAttr(el, "name"), safeAttr(el, "type"), safeAttr(el, "id"));
            }

            // 3) Submit button inside form
            WebElement submitBtn = locateSubmitElement(driver, pageURL);
            System.out.println("\nSubmit button found:");
            System.out.printf(" - tag=%s, type=%s, text='%s'%n",
                    submitBtn.getTagName(), safeAttr(submitBtn, "type"), submitBtn.getText().trim());

            // 4) Inputs with missing id
            List<WebElement> idMissingInputs = locateIdMissingElements(driver, pageURL);
            System.out.println("\n<form> inputs missing 'id' attribute: " + idMissingInputs.size());
            for (WebElement el : idMissingInputs) {
                System.out.printf(" - name=%s, type=%s%n",
                        safeAttr(el, "name"), safeAttr(el, "type"));
            }

        } catch (NoSuchElementException nse) {
            System.err.println("Element not found: " + nse.getMessage());
        } catch (WebDriverException wde) {
            System.err.println("WebDriver error: " + wde.getMessage());
        } finally {
            driver.quit();
        }
    }

    // Helper to avoid NullPointer on missing attributes
    private static String safeAttr(WebElement el, String attr) {
        String val = el.getAttribute(attr);
        return (val == null || val.isBlank()) ? "<missing>" : val;
    }
}
