
package com.selenium.mavenSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.time.Duration;

public class demo {

    private WebDriver driver;
    private WebDriverWait wait;

    @BeforeClass
    public void beforeClass() {

        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        driver.get("https://www.calculator.net/percent-calculator.html");
        System.out.println("Percentage Calculator opened");

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cpar1")));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("cpar2")));
    }

    /*
     * Test Case 1:
     * Enter keys, get the result, clear
     */
    @Test(priority = 1)
    public void percentageCalculationAndClear() {
        WebElement input1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("cpar1")));
        WebElement input2 = wait.until(ExpectedConditions.elementToBeClickable(By.id("cpar2")));

        input1.clear();
        input2.clear();

        input1.sendKeys("20");
        input2.sendKeys("100");

        WebElement submit = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input[type='submit']")));
        submit.click();

        WebElement result = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.h2result")));
        String resultText = result.getText().trim();
        System.out.println("Test Case 1 Result: " + resultText);

        input1.clear();
        input2.clear();
        System.out.println("Test Case 1: Inputs cleared");
    }

    /**
     * Test Case 2:
     * Enter keys, get the result, print the result in Console and Reporter.log
     */
    @Test(priority = 2)
    public void percentageCalculationAndLog() {
        WebElement input1 = wait.until(ExpectedConditions.elementToBeClickable(By.id("cpar1")));
        WebElement input2 = wait.until(ExpectedConditions.elementToBeClickable(By.id("cpar2")));

        input1.clear();
        input2.clear();
        input1.sendKeys("50");
        input2.sendKeys("80");

        WebElement submit = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("input[type='submit']")));
        submit.click();

        WebElement result = wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.h2result")));
        String resultText = result.getText().trim();

        System.out.println("Test Case 2 Result: " + resultText);
        Reporter.log("Test Case 2 - Percentage Calculation Result: " + resultText, true);
    }

    @AfterClass
    public void afterClass() {
        if (driver != null) {
            driver.quit();
            System.out.println("Browser closed");
        }
    }
}