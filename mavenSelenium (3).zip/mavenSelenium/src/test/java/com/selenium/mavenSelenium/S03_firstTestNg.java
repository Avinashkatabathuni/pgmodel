package com.selenium.mavenSelenium;
 
import org.openqa.selenium.By;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
 
import java.time.Duration;
 
public class S03_firstTestNg {
 
    private WebDriver driver;
 
    @BeforeClass
    public void launchBrowser() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.google.com");
        System.out.println("Launched Browser");
        
    }
 
    @Test
    public void testSearch() throws InterruptedException {
        
        WebElement searchText = driver.findElement(By.name("q"));
        String searchKey = "Hello Welcome!!";
        searchText.sendKeys(searchKey);
        System.out.println("Your search key is "+searchKey);
        Thread.sleep(3000);
        String testValue=searchText.getText();
        System.out.println(testValue+"----"+searchKey);
        
    }
 
   @AfterClass
    public void closeBrowser() {
     
            driver.close();
            System.out.println("Execution Completed");
        }
    }
 