package com.selenium.mavenSelenium;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class S11_Alerts {
	WebDriver driver;
	
	@BeforeClass
	public void Launch() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/alerts");
		
		//Implicit Wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		System.out.println("Title of the page: " + driver.getTitle());
		System.out.println("URL Launched");
	}
	
	@AfterClass
	public void Close() {
		//driver.quit();
		System.out.println("execution Complete");
	}
	
	
	@Test
	public void AlertsMouseClick() {
		driver.findElement(By.id("alertButton")).click();
		
		//Switch to Alert
		Alert simpleAlert = driver.switchTo().alert();
		//Accept Alert
		simpleAlert.accept();
		
		driver.findElement(By.id("alertButton")).click();
		Alert simAlert = driver.switchTo().alert();
		simAlert.dismiss();
	}

}
