package com.selenium.mavenSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class S09_KeyBoard_Actions {

	WebDriver driver;
	WebElement fName;
	
	@BeforeClass
	public void Launch() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.tutorialspoint.com/selenium/practice/text-box.php");
		Reporter.log("Launched URL", true);
	}
	
	@Test
	public void a_keyDown_Up() {
		//WebElement - TextBox
		fName = driver.findElement(By.id("fullname"));
		
		//Initialized Action Class Object
		Actions actionKeys = new Actions(driver);
		fName.click();
		
		//Object of Action Class on this input box.
		actionKeys.keyDown(Keys.SHIFT)
				  .sendKeys("a")
				  .keyUp(Keys.SHIFT)
				  .sendKeys("mazing")
				  .keyDown(Keys.SHIFT)
				  .sendKeys("111")
				  .keyUp(Keys.SHIFT)
				  .perform();
		
		fName.sendKeys(Keys.TAB);
		Assert.assertEquals("Amazing!!!", fName.getAttribute("value"));
		Reporter.log("Entered Name: " + fName.getAttribute("value"));
	}
	
	@Test
	public void b_sendKeysToActiveElements() {
		new Actions(driver).sendKeys("nkc@gmail.com").perform();
		WebElement email = driver.findElement(By.id("email"));
		Assert.assertEquals("nkc@gmail.com", email.getAttribute("value"));
		Reporter.log("Entered Email: " + email.getAttribute("value"));
	}
	
	@Test
	public void c_sendKeysToDesignatedElement() {
		driver.findElement(By.tagName("body")).click();
		WebElement pwd=driver.findElement(By.id("password"));
//		pwd.sendKeys("hi");
		new Actions(driver).sendKeys(pwd, "Selenium!").perform();
		Assert.assertEquals("Selenium!", pwd.getAttribute("value"));
		Reporter.log("Entered password: "+pwd.getAttribute("value"),true);
	}
	
	@Test
	public void d_copyAndPaste() {
		//WebElement Address = driver.findElement(By.id("address"));
		Keys cmdCtrl = Platform.getCurrent().is(Platform.MAC)?Keys.COMMAND:Keys.CONTROL;
		
		//Cut and Paste
		new Actions(driver).sendKeys(fName, Keys.ARROW_LEFT)
						   .keyDown(Keys.SHIFT)
						   .sendKeys(Keys.ARROW_UP)
						   .keyUp(Keys.SHIFT)
						   .keyDown(cmdCtrl).sendKeys("xvv").keyUp(cmdCtrl)
						   .perform();
		Reporter.log("Name: " + fName.getAttribute("value"));
		Actions a = new Actions(driver);
		a.keyDown(cmdCtrl);
		a.sendKeys("a");
		a.keyUp(cmdCtrl);
		a.build().perform();
		
		//Actions class method to copy text
		a.keyDown(cmdCtrl);
		a.sendKeys("c");
		a.keyUp(cmdCtrl);
		a.build().perform();
		
		//Actions class method to tab and reach the next input box
		a.sendKeys(Keys.TAB);
		a.sendKeys(Keys.TAB);
		a.build().perform();
		
		//Actions class methods to paste text
		a.keyDown(cmdCtrl);
		a.sendKeys("v");
		a.build().perform();
		
	}
}
