package com.selenium.mavenSelenium;
 
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
 
public class S08_PriorityLogs {
  @Test(groups= "sanity", priority=0)
  public void f() {
	  System.out.println("test Main");
	  Reporter.log("Starting test case: User Login");
  }
  @Test(groups={"smoke","sanity"})
  public void apple() {
	  System.out.println("Apple method");
  }
  @Test(groups= "smoke", priority=7)
  public void banana() {
	  System.out.println("banana method");
  }
  @Test(priority=-1)
  public void citrus() {
	  System.out.println("citrus method");
  }
  @BeforeClass
  public void beforeClass() {
	  System.out.println("BEfore Class");
  }
 
  @AfterClass
  public void afterClass() {
	  System.out.println("After Class");
  }
 
}