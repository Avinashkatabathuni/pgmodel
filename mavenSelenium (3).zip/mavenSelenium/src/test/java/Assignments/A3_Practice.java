//Fill Name field using Find By ID
//Select Gender radio button by using find by Xpath 
//Fill Email field using Fild By Type 
//Fill Mobile Number field using Fild By ID 
//Select DOB radio button by using find by ID
//Select Hobbies field using Fild By XPath 
//Upload Image into Picture field using Full XPath
//Fill Address by using Field By Name
//Select State using ID and Select By Index
//Select City using Name and Select By Visible Text
//Click Login Button using XPath

package Assignments;

import java.util.List;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class A3_Practice {

	public static void main(String[] args) {
		String PageUrl = "https://www.tutorialspoint.com/selenium/practice/selenium_automation_practice.php";
		WebDriver driver = new ChromeDriver();
		driver.get(PageUrl);
		driver.manage().window().maximize();
		
		//Fill Name field using Find By ID
		WebElement name = driver.findElement(By.id("name"));
		name.sendKeys("Krishna");
		
		//Fill Email field using Fild By Type 
		WebElement email = driver.findElement(By.xpath("//input[@type=\"email\"]"));
		email.sendKeys("nkc@gmail.com");
		
		//Select Gender radio button by using find by Xpath 
		//WebElement gender = driver.findElement(By.xpath("//input[@type=\"radio\"]"));
		WebElement gender = driver.findElement(By.xpath("//*[@id=\"gender\"]"));
		gender.click();
		
		//Fill Mobile Number field using Fild By ID
		WebElement num = driver.findElement(By.xpath("//*[@id=\"mobile\"]"));
		num.sendKeys("8688152369");
		
		//Select DOB radio button by using find by ID
		WebElement dob = driver.findElement(By.id("dob"));
		dob.sendKeys("07/17/2002");
		
		//Fill Subjects field using Fild By Type 
		WebElement subject = driver.findElement(By.id("subjects"));
		subject.sendKeys("AT");
	/*	
		//Select Hobbies field using Fild By XPath 
		WebElement hobbies = driver.findElement(By.xpath("//input[@type='checkbox']"));
//		Select select = new Select(hobbies);
//		hobbies.se
		
		//System.out.prin)
		Select multipleSelect=new Select(hobbies);
		multipleSelect.selectByIndex(0);
		System.out.println(multipleSelect.getOptions());
		
		*/
		
		
		//List<WebElement> list=driver.findElements(By.xpath("//input[@class='form-check-input mt-0' and @type='checkbox']"));
		//System.out.println(list.size());
		WebElement sports = driver.findElement(By.xpath("//*[@id=\"hobbies\"]"));
		sports.click();
		WebElement reading = driver.findElement(By.xpath("//*[@id=\"practiceForm\"]/div[7]/div/div/div[2]/input"));
		reading.click();

//		for (int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i));
//		
//		}
//		List<WebElement> names=driver.findElements(By.xpath("//label[@class=\"col-form-label\"]"));
//		System.out.println(names.size());
//		for(int i=0;i<list.size();i++) {
//			System.out.println(list.get(i));
//			//WebElement driver.findElements(By.xpath("//input[@class='form-check-input mt-0' and @type='checkbox']"));
//			
//		}
		
		
		
		//Upload Image into Picture field using Full XPath
		WebElement picture = driver.findElement(By.xpath("/html/body/main/div/div/div[2]/form/div[8]/div/div/input"));
		picture.sendKeys("C:\\NKC\\Personal\\HClTECH LOGO.png");
		
		//Fill Address by using Field By Name
		WebElement Address = driver.findElement(By.xpath("//textarea[@placeholder=\"Currend Address\"]"));
		Address.sendKeys("DRR Mens PG, Karapakkam");
		
		//Select State using ID and Select By Index
		WebElement state = driver.findElement(By.id("state"));
		//Select select = new Select(state);
		//select.selectByIndex(2);
		
		Select select = new Select(state);
		select.selectByContainsVisibleText("Uttar ");
		
		//Select City using Name and Select By Visible Text
		WebElement city = driver.findElement(By.name("city"));
		Select select2 = new Select(city);
		select2.selectByValue("Meerut");
		
		//Click Login Button using XPath
		//WebElement LoginBtn = driver.findElement(By.xpath("//input[@value='Login']"));
		WebElement LoginBtn = driver.findElement(By.xpath("WebElement LoginBtn = driver.findElement(By.xpath(\"//input[@value='Login']\"));"));
		LoginBtn.click();
		System.out.println("Clicked on Login Button");
		
	}
}
