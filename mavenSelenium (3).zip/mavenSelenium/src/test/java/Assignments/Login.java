

package Assignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Login {

    WebDriver driver;

    private final By emailField = By.id("email");
    private final By passwordField = By.id("password");
    private final By submitBtn = By.xpath("//input[@type='submit']");

    private final String storedEmail = "Krishna@gmail.com";
    private final String storedPassword = "Krishna@123";

    @BeforeClass
    public void beforeclass() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://www.tutorialspoint.com/selenium/practice/login.php");
    }

    @AfterClass
    public void afterclass() {
        if (driver != null) {
            driver.quit();
        }
    }

    @BeforeMethod
    public void clearFields() {
        driver.findElement(emailField).clear();
        driver.findElement(passwordField).clear();
    }

    @Test(priority = 1, description = "Validate login with correct credentials using sendKeys")
    public void testValidLogin() throws InterruptedException {
        String enteredEmail = "Krishna@gmail.com";
        String enteredPassword = "Krishna@123";

        driver.findElement(emailField).sendKeys(enteredEmail);
        driver.findElement(passwordField).sendKeys(enteredPassword);
        driver.findElement(submitBtn).click();
        String actualEmailInField = driver.findElement(emailField).getAttribute("value");
        String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

        if (actualEmailInField.equals(storedEmail) && actualPasswordInField.equals(storedPassword)) {
            System.out.println("Login Successful!");
            Assert.assertTrue(true, "Entered credentials match stored credentials");
        } else {
            System.out.println("Credentials are Invalid");
            Assert.fail("Entered credentials do not match stored credentials");
        }

        Thread.sleep(1000);
    }

    @Test(priority = 2, description = "Validate login with incorrect password using sendKeys")
    public void testInvalidPassword() throws InterruptedException {
        String enteredEmail = "Krishna@gmail.com";
        String enteredPassword = "WrongPassword";

        driver.findElement(emailField).sendKeys(enteredEmail);
        driver.findElement(passwordField).sendKeys(enteredPassword);
        driver.findElement(submitBtn).click();

        String actualEmailInField = driver.findElement(emailField).getAttribute("value");
        String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

        if (actualEmailInField.equals(storedEmail) && actualPasswordInField.equals(storedPassword)) {
            System.out.println("Login Successful!");
            Assert.fail("Should not succeed: password is wrong");
        } else {
            System.out.println("Invalid Password!");
            Assert.assertTrue(true, "Mismatch as expected for wrong password");
        }

        Thread.sleep(1000);
    }

    @Test(priority = 3, description = "Validate login with incorrect email using sendKey")
    public void testInvalidEmail() throws InterruptedException {
        String enteredEmail = "WrongEmail@gmail.com";
        String enteredPassword = "Krishna@123";

        driver.findElement(emailField).sendKeys(enteredEmail);
        driver.findElement(passwordField).sendKeys(enteredPassword);
        driver.findElement(submitBtn).click();

        String actualEmailInField = driver.findElement(emailField).getAttribute("value");
        String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

        if (actualEmailInField.equals(storedEmail) && actualPasswordInField.equals(storedPassword)) {
            System.out.println("Login Successful!");
            Assert.fail("Should not succeed: email is wrong");
        } else {
            System.out.println("Invalid Email");
            Assert.assertTrue(true, "Mismatch as expected for wrong email");
        }

        Thread.sleep(1000);
    }
    
    @Test(priority = 4, description = "Validate login with empty fields")
    public void testEmptyFields() throws InterruptedException {
        String enteredEmail = "";
        String enteredPassword = "";

        driver.findElement(emailField).sendKeys(enteredEmail);
        driver.findElement(passwordField).sendKeys(enteredPassword);
        driver.findElement(submitBtn).click();

        String actualEmailInField = driver.findElement(emailField).getAttribute("value");
        String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

        if (actualEmailInField.equals(storedEmail) && actualPasswordInField.equals(storedPassword)) {
            System.out.println("Login Successful!");
            Assert.fail("Should not succeed: Invalid Credentials");
        } else {
            System.out.println("Empty Fields");
            Assert.assertTrue(true, "Invalid Credentials");
        }

        Thread.sleep(1000);
    }
        
        @Test(priority = 5, description = "Validate login with empty fields")
        public void InvalidFields() throws InterruptedException {
            String enteredEmail = "nkc@gmail.com";
            String enteredPassword = "Password";

            driver.findElement(emailField).sendKeys(enteredEmail);
            driver.findElement(passwordField).sendKeys(enteredPassword);
            driver.findElement(submitBtn).click();

            String actualEmailInField = driver.findElement(emailField).getAttribute("value");
            String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

            if (actualEmailInField.equals(storedEmail) && actualPasswordInField.equals(storedPassword)) {
                System.out.println("Login Successful!");
                Assert.fail("Should not succeed: Invalid Credentials");
            } else {
                System.out.println("Invalid Email and Password!");
                Assert.assertTrue(true, "Invalid Credentials");
            }

            Thread.sleep(1000);
    }
}
