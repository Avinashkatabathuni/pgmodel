//Fill Email Field using id
//Fill Password Field using name
//Click on New User Button using Xpath

package Assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A1_Login {

	public static void main(String[] args) {
		
		String PageUrl = "https://www.tutorialspoint.com/selenium/practice/login.php";
		WebDriver driver = new ChromeDriver();
		driver.get(PageUrl);
		
		//Fill Email Field using id
		WebElement email = driver.findElement(By.id("email"));
		email.sendKeys("nkcpathuri");
		
		//Fill Password Field using name
		WebElement pass = driver.findElement(By.name("password"));
		pass.sendKeys("NKC");
		
		//Click on New User Button using Xpath
		WebElement loginclick = driver.findElement(By.xpath("//*[@id=\"signInForm\"]/div[3]/a"));
		//WebElement loginclick = driver.findElement(By.className("btn btn-primary ms-4"));
		loginclick.click();
	}
}
