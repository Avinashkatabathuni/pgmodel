package Assignments;
 
import java.time.Duration;
import java.util.List;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
public class A5_TableElements {
	WebDriver driver;
  @Test
  public void f() {
	  List<WebElement> list=driver.findElements(By.xpath("//table/tbody/tr"));
	  for(int i=0;i<list.size();i++) {
		  List<WebElement> li=driver.findElements(By.tagName("td"));
		  System.out.println(li.get(2).getText());
	  }
  }
  @BeforeClass
  public void beforeClass() {
	  driver=new ChromeDriver();
	  driver.get("https://www.tutorialspoint.com/selenium/practice/webtables.php#");
	  driver.manage().window().maximize();
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
  }
  @AfterClass
  public void afterClass() throws InterruptedException {
	  Thread.sleep(4000);
	  driver.quit();
  }
}