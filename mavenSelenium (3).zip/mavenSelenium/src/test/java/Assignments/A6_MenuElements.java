package Assignments;
 
import java.time.Duration;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
public class A6_MenuElements {
    WebDriver driver;
    @BeforeClass
    public void beforeClass() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(0));
        driver.get("https://demoqa.com/menu");
    }
    @Test
    public void MenuInteration() throws InterruptedException {   
        Actions act = new Actions(driver);
        WebElement ele = driver.findElement(By.xpath(".//li[a[normalize-space()='Main Item 2']]/a"));
        WebElement web=driver.findElement(By.xpath("//*[@id=\"nav\"]/li[2]/ul/li[3]/a"));
        WebElement sub=driver.findElement(By.xpath("//*[@id=\"nav\"]/li[2]/ul/li[3]/ul/li[1]/a"));
        act.moveToElement(ele).moveToElement(web).moveToElement(sub).perform();
        Thread.sleep(5000);
    }
    @AfterClass
    public void afterClass() {
        driver.quit();
    }
}