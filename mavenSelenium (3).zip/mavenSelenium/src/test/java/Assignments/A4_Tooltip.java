package Assignments;
 
import java.time.Duration;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class A4_Tooltip {
	WebDriver driver;

	 @BeforeClass
	  public void beforeClass() {
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.get("https://demoqa.com/tool-tips");

	  }


  @Test
  public void ToolTip() throws InterruptedException {
	  WebElement button=driver.findElement(By.id("toolTipButton"));
	  Actions actions=new Actions(driver);
	  actions.moveToElement(button).build().perform();
	  WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	  WebElement tooltipInner = wait.until(
			  ExpectedConditions.visibilityOfElementLocated(By.cssSelector(".tooltip-inner"))
			  );
	  String hoveredText = tooltipInner.getText().trim();
	  System.out.println("Hovered Text: " + hoveredText);


  }
  @AfterClass
  public void afterClass() {
	  System.out.println("execution Completed");
  }
}