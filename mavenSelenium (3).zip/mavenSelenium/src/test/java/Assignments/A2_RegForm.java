//Fill First Name Field using id
//Fill Last Name Field using id
//Fill Username Field using id
//Fill Password Field using id
//Click on Back To Login Button using Xpath

package Assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class A2_RegForm {

	public static void main(String[] args) {
	
		String PageUrl = "https://www.tutorialspoint.com/selenium/practice/register.php";
		WebDriver driver = new ChromeDriver();
		driver.get(PageUrl);

		//Fill First Name Field using id
		WebElement fname = driver.findElement(By.id("firstname"));
		fname.sendKeys("N Krishna");
		
		//Fill Last Name Field using id
		WebElement lname = driver.findElement(By.id("lastname"));
		lname.sendKeys("Chowdary Pathuri");


		//Fill Username Field using id
		WebElement uname = driver.findElement(By.id("username"));
		uname.sendKeys("nkcpathuri");
		
		//Fill Password Field using id
		WebElement pass = driver.findElement(By.id("password"));
		pass.sendKeys("NKC");
		
		//Click on Back To Login Button using Xpath
		WebElement regclick = driver.findElement(By.xpath("//*[@id=\"signupForm\"]/div[5]/a"));
		regclick.click();
		
	}
}
