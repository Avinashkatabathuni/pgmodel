
package Assignments;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Login_Page {

    WebDriver driver;

    // Locators
    private final By emailField = By.id("email");
    private final By passwordField = By.id("password");
    private final By submitBtn = By.xpath("//input[@type='submit']");

    // Stored credentials (baseline)
    private final String storedEmail = "Krishna@gmail.com";
    private final String storedPassword = "Krishna@123";

    @BeforeClass
    public void beforeclass() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.get("https://www.tutorialspoint.com/selenium/practice/login.php");
    }

    @AfterClass
    public void afterclass() {
        if (driver != null) {
            driver.quit();
        }
    }

    @BeforeMethod
    public void clearFields() {
        driver.findElement(emailField).clear();
        driver.findElement(passwordField).clear();
    }

    @Test(priority = 1, description = "Validate login with correct credentials using sendKeys (soft assertions)")
    public void testValidLogin() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();

        // Inputs
        String enteredEmail = "Krishna@gmail.com";
        String enteredPassword = "Krishna@123";

        // Type values
        driver.findElement(emailField).sendKeys(enteredEmail);
        driver.findElement(passwordField).sendKeys(enteredPassword);
        driver.findElement(submitBtn).click();

        // Read back values from DOM
        String actualEmailInField = driver.findElement(emailField).getAttribute("value");
        String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

        // Simple comparisons + soft asserts (no errors thrown)
        boolean emailMatches = actualEmailInField.equals(storedEmail);
        boolean passwordMatches = actualPasswordInField.equals(storedPassword);

        if (emailMatches && passwordMatches) {
            System.out.println("Login Successful!");
        } else {
            System.out.println("Credentials are Invalid");
        }

        // Soft checks for reporting
        softAssert.assertTrue(emailMatches, "Email should match stored email");
        softAssert.assertTrue(passwordMatches, "Password should match stored password");

        // Do NOT call assertAll(); prevents test failure
        // softAssert.assertAll();

        Thread.sleep(1000);
    }

    @Test(priority = 2, description = "Validate login with incorrect password")
    public void testInvalidPassword() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();

        String enteredEmail = "Krishna@gmail.com";
        String enteredPassword = "WrongPassword";

        driver.findElement(emailField).sendKeys(enteredEmail);
        driver.findElement(passwordField).sendKeys(enteredPassword);
        driver.findElement(submitBtn).click();

        String actualEmailInField = driver.findElement(emailField).getAttribute("value");
        String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

        boolean emailMatches = actualEmailInField.equals(storedEmail);
        boolean passwordMatches = actualPasswordInField.equals(storedPassword);

        if (emailMatches && passwordMatches) {
            System.out.println("Login Successful! (Unexpected for invalid password)");
        } else {
            System.out.println("Invalid Password!");
        }

        softAssert.assertTrue(emailMatches, "Email should match stored email");
        softAssert.assertFalse(passwordMatches, "Password should NOT match stored password");

        // softAssert.assertAll();
        Thread.sleep(1000);
    }

    @Test(priority = 3, description = "Validate login with incorrect email")
    public void testInvalidEmail() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();

        String enteredEmail = "WrongEmail@gmail.com";
        String enteredPassword = "Krishna@123";

        driver.findElement(emailField).sendKeys(enteredEmail);
        driver.findElement(passwordField).sendKeys(enteredPassword);
        driver.findElement(submitBtn).click();

        String actualEmailInField = driver.findElement(emailField).getAttribute("value");
        String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

        boolean emailMatches = actualEmailInField.equals(storedEmail);
        boolean passwordMatches = actualPasswordInField.equals(storedPassword);

        if (emailMatches && passwordMatches) {
            System.out.println("Login Successful! (Unexpected for invalid email)");
        } else {
            System.out.println("Invalid Email");
        }

        softAssert.assertFalse(emailMatches, "Email should NOT match stored email");
        softAssert.assertTrue(passwordMatches, "Password should match stored password");

        // softAssert.assertAll();
        Thread.sleep(1000);
    }

    @Test(priority = 4, description = "Validate login with empty fields")
    public void testEmptyFields() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();

        String enteredEmail = "";
        String enteredPassword = "";

        driver.findElement(emailField).sendKeys(enteredEmail);
        driver.findElement(passwordField).sendKeys(enteredPassword);
        driver.findElement(submitBtn).click();

        String actualEmailInField = driver.findElement(emailField).getAttribute("value");
        String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

        boolean emailMatches = actualEmailInField.equals(storedEmail);
        boolean passwordMatches = actualPasswordInField.equals(storedPassword);

        if (emailMatches && passwordMatches) {
            System.out.println("Login Successful! (Unexpected for empty fields)");
        } else {
            System.out.println("Empty Fields");
        }

        softAssert.assertFalse(emailMatches, "Email should NOT match when empty");
        softAssert.assertFalse(passwordMatches, "Password should NOT match when empty");

        // softAssert.assertAll();
        Thread.sleep(1000);
    }

    @Test(priority = 5, description = "Validate login with invalid fields")
    public void InvalidFields() throws InterruptedException {
        SoftAssert softAssert = new SoftAssert();

        String enteredEmail = "nkc@gmail.com";
        String enteredPassword = "Password";

        driver.findElement(emailField).sendKeys(enteredEmail);
        driver.findElement(passwordField).sendKeys(enteredPassword);
        driver.findElement(submitBtn).click();

        String actualEmailInField = driver.findElement(emailField).getAttribute("value");
        String actualPasswordInField = driver.findElement(passwordField).getAttribute("value");

        boolean emailMatches = actualEmailInField.equals(storedEmail);
        boolean passwordMatches = actualPasswordInField.equals(storedPassword);

        if (emailMatches && passwordMatches) {
            System.out.println("Login Successful! (Unexpected for invalid fields)");
        } else {
            System.out.println("Invalid Email and Password!");
        }

        softAssert.assertFalse(emailMatches, "Email should NOT match stored email");
        softAssert.assertFalse(passwordMatches, "Password should NOT match stored password");

        // softAssert.assertAll();
        Thread.sleep(1000);
    }
}
