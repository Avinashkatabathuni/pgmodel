package LoginForm;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.gargoylesoftware.htmlunit.javascript.host.Element;

public class Login_Form_Field_Validate {

	WebDriver driver;

	@BeforeClass
	public void beforeclass() {
		driver = new ChromeDriver();
		driver.get("https://www.tutorialspoint.com/selenium/practice/login.php");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@AfterClass
	public void afterclass() {
		driver.quit();
	}

	// Clear both fields and make sure that the fields are empty

	@BeforeMethod
	public void clearFields() {
		driver.findElement(By.id("email")).clear();
		driver.findElement(By.id("password")).clear();
	}

	// Enter Valid email and valid password

	@Test(priority = 1, description = "Valid email and valid password")
	public void validLogin() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Krishna@123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Valid email and invalid password

	@Test(priority = 2, description = "Valid email and invalid password")
	public void validEmailInvalidPassword() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna@gmail.com");
		driver.findElement(By.id("password")).sendKeys("ydgaiuwh");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Invalid email and valid password

	@Test(priority = 3, description = "Invalid email and valid password")
	public void invalidEmailValidPassword() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Kr@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Krishna@123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Invalid email and invalid password

	@Test(priority = 4, description = "Invalid email and invalid password")
	public void invalidEmailInvalidPassword() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna");
		driver.findElement(By.id("password")).sendKeys("ajsns123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Email with special characters

	@Test(priority = 5, description = "Email with special characters")
	public void emailWithSpecialChars() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna!@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Krishna@123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Email without @ symbol

	@Test(priority = 6, description = "Email without @ symbol")
	public void emailWithoutAtSymbol() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna123.com");
		driver.findElement(By.id("password")).sendKeys("Krishna@123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Email without domain

	@Test(priority = 7, description = "Email without domain")
	public void emailWithoutDomain() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna@");
		driver.findElement(By.id("password")).sendKeys("Krishna@123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Password with only numbers

	@Test(priority = 8, description = "Password with only numbers")
	public void passwordOnlyNumbers() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna@gmail.com");
		driver.findElement(By.id("password")).sendKeys("123456");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Password with only letters

	@Test(priority = 9, description = "Password with only letters")
	public void passwordOnlyLetters() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna@gmail.com");
		driver.findElement(By.id("password")).sendKeys("abcdef");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Password with special characters only

	@Test(priority = 10, description = "Password with special characters only")
	public void passwordSpecialCharsOnly() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna@gmail.com");
		driver.findElement(By.id("password")).sendKeys("@#$%^&*");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Email in uppercase

	@Test(priority = 11, description = "Email in uppercase")
	public void emailUppercase() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("KRISHNA@GMAIL.COM");
		driver.findElement(By.id("password")).sendKeys("Krishna@123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		WebElement el = driver.findElement(By.xpath("//input[@type='submit']"));
		el.getCssValue(null);
		Thread.sleep(1000);
	}

	// Enter Password in uppercase

	@Test(priority = 12, description = "Password in uppercase")
	public void passwordUppercase() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna@gmail.com");
		driver.findElement(By.id("password")).sendKeys("KRISHNA@123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Email with spaces

	@Test(priority = 13, description = "Email with spaces")
	public void emailWithSpaces() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys(" Krishna@gmail.com ");
		driver.findElement(By.id("password")).sendKeys("Krishna@123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Password with spaces

	@Test(priority = 14, description = "Password with spaces")
	public void passwordWithSpaces() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna@gmail.com");
		driver.findElement(By.id("password")).sendKeys(" Krishna@123 ");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Very long email

	@Test(priority = 15, description = "Very long email")
	public void veryLongEmail() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("qwertyuiopasdfghjklmnbvcxzlkjhgfdsapoiuytrewq@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Krishna@123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}

	// Enter Very long password

	@Test(priority = 16, description = "Very long password")
	public void veryLongPassword() throws InterruptedException {
		driver.findElement(By.id("email")).sendKeys("Krishna@gmail.com");
		driver.findElement(By.id("password")).sendKeys("mnbvcxzlkjhgfdsaqwertyuiopoijhgfdxzsdfgbn123");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		Thread.sleep(1000);
	}
}