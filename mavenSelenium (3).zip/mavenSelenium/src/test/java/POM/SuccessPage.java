package POM;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SuccessPage {

	private WebDriver driver;
	private WebDriverWait wait;
	
	//Constructor for SuccessPage 
	public SuccessPage(WebDriver driver) {
		this.driver = driver;
		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		
	}
	
	By successMessage = By.xpath("//h1[normalize-space()='Logged In Successfully']");
	By LogoutLink = By.linkText("Log out");
	
	//Method to check SuccessMessage
	public boolean DisplaySuccessMessage() {
		boolean displaySuccessMessage = driver.findElement(successMessage).isDisplayed();
		return displaySuccessMessage;
	}
	
	public String SuccessMessageText() {
		WebElement successMsg = wait.until(ExpectedConditions.visibilityOfElementLocated(successMessage));
		String SuccessMessageText = successMsg.getText();
		return SuccessMessageText;
	}
	
	public boolean logoutDisplayed() {
		boolean logout = driver.findElement(LogoutLink).isDisplayed();
		return logout;
	}
	
	
}
