package POM;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class PageFactoryTest {

	static WebDriver driver;
	
	@BeforeClass
	public void Launch() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://demoqa.com/login");
		driver.manage().timeouts().implicitlyWait(Duration.ofMillis(500));
	}
	
	@AfterClass
	public void Close() {
		//driver.close();
		System.out.println("Execution Complete");
	}
	
	@Test
	public void LoginTest() {
		
		//Instantiating Login and Profile Page
		PageFactoryLogin loginpg = new PageFactoryLogin(driver);
		PageFactoryProfile profilepg = new PageFactoryProfile(driver);
		
		//Using the methods created in Pages class to perform actions
		loginpg.LogIn_Action("TestNg", "Mercury25");
		String actualUser = profilepg.actualUsername();
		Assert.assertEquals(actualUser, "TestNg", "username does not match");
		profilepg.logout_Action();
	}
	
}
