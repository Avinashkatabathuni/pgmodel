package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Constats_LoginTest {

	private WebDriver driver;
	
	@BeforeMethod
	public void setup() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(Constants.Login_URL);
	}
	
	@AfterMethod
	public void close() {
		if(driver != null) {
			//driver.quit();
			System.out.println("Execution Completed");
		}
	}
	
	@Test
	public void testSuccessfulLogin() {
		LoginPage loginPage = new LoginPage(driver);
		
		//Type Username
		loginPage.typeUsername(Constants.Username);
		
		//Type Password
		loginPage.typePassword(Constants.Password);
		
		//Click on Submit Button
		loginPage.SubmitClick();
		
		//
		SuccessPage successPage = new SuccessPage(driver);
		
		//Verify the Success Message is Displayed
		Assert.assertTrue(successPage.logoutDisplayed());
	}
	
	
}
