package POM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class VerifyLogin {

	WebDriver driver;
	
	@BeforeMethod
	public void setUp() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://practicetestautomation.com/practice-test-login/");
	}
	
	@AfterMethod
	public void teardown() {
		if (driver!=null) {
			driver.quit();
		}
	}
	
	@Test
	public void testSuccessLogin() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.typeUsername("student");
		loginPage.typePassword("Password123");
		loginPage.SubmitClick();
		
		SuccessPage searchPage = new SuccessPage(driver);
		searchPage.SuccessMessageText();
		searchPage.SuccessMessageText();
		searchPage.logoutDisplayed();
		System.out.println(searchPage.SuccessMessageText());
		System.out.println(searchPage.SuccessMessageText());
		Assert.assertTrue(searchPage.logoutDisplayed());
		
	}
	
	@Test
	public void NegativeLoginTest() {
		LoginPage loginPage = new LoginPage(driver);
		loginPage.typeUsername("Krishna");
		loginPage.typePassword("Password123");
		loginPage.SubmitClick();
		loginPage.ErrorMsgDisplay();
		loginPage.ErrorMsgTextDisplay();
		Assert.assertTrue(loginPage.ErrorMsgDisplay());
		System.out.println(loginPage.ErrorMsgTextDisplay());
	}
}
