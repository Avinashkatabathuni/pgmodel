package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {

	private WebDriver driver;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	// Locate the Input Fields Username and Password
	By username = By.name("username");
	By password = By.name("password");
	By SubmitBtn = By.id("submit");
	By ErrorMsg = By.id("error");

	// Method to type Username
	public void typeUsername(String uname) {
		driver.findElement(username).sendKeys("student");
	}

	// Method to type Password
	public void typePassword(String pass) {
		driver.findElement(password).sendKeys("Password123");
	}

	// Method to Click on Submit Button
	public void SubmitClick() {
		driver.findElement(SubmitBtn).click();
	}

	// Method to display Error Message
	public boolean ErrorMsgDisplay() {
		boolean errMsgDisplay = driver.findElement(ErrorMsg).isDisplayed();
		return errMsgDisplay;
	}

	// Method to display Error Message Text
	public String ErrorMsgTextDisplay() {
		String errMsgText = driver.findElement(ErrorMsg).getText();
		return errMsgText;
	}

	public WebElement getUsernameField() {
		return driver.findElement(By.id("username"));
	}

	public WebElement getPasswordField() {
		return driver.findElement(By.id("password"));
	}

	public WebElement getLoginButton() {
		return driver.findElement(By.id("submit"));
	}

	// Method for Login Process
	public void Login(String username, String Password) {
		getUsernameField().sendKeys(username);
		getPasswordField().sendKeys(Password);
		getLoginButton().click();

	}
}
