/*
 * @FindBy
 * @FindBys
 * @FindAll
 */


package POM;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryLogin {
	
	final WebDriver driver;

	public PageFactoryLogin(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, true);
	}
	
	// Locating the username text box using @FindBys
	// Locates the web element by using AND condition
	// Implying a Parent-Child or Hierarchical relationship
	
	@FindBys({
		@FindBy(id="userName-wrapper"), //Parent
		@FindBy(id="userName") //Child
	})
	WebElement username;
	//Method 1
	//Locating the password text box
	@FindBy(id="password")
	
	WebElement password;
	
	//Method 2
	//Locating Login Button with how Enum and using
	@FindBy(how = How.ID, using="login")
	WebElement loginBtn;
	
	//For List --eg
	//@FindBy(tagName="iframes")
	//List<WebElement> iframelist;
	
	//Method that performs login action using web elements
	public void LogIn_Action(String uName, String pwd) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrolltoView(true)", password);
		username.sendKeys(uName);
		password.sendKeys(pwd);
		loginBtn.click();
	}
	
}
