package seleniumassessment;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
 
public class CalculatorTest {
	WebDriver driver;
	
	@BeforeTest
	public void openUrl() {
		driver = new ChromeDriver();
		driver.get("https://www.calculator.net/percent-calculator.html");
	}
	
	@AfterTest
	public void closeUrl() {
		driver.close();
	}
	
	@Test
	public void Print() {
		driver.findElement(By.id("cpar1")).sendKeys("100");
		driver.findElement(By.id("cpar2")).sendKeys("1000");
		driver.findElement(By.name("x")).click();
		
		WebElement result = driver.findElement(By.className("h2result"));
		
		Reporter.log("Percentage " + result.getText(), true);
	}
}