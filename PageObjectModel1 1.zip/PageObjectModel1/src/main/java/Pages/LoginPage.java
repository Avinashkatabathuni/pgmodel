package Pages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.testng.annotations.Test;
 
public class LoginPage {
  private WebDriver driver;
  public  LoginPage(WebDriver driver) {
	  this.driver = driver;
  }
  By username = By.name("username");
  By Password = By.name("password");
  By SignInButton = By.id("submit");
  By errorMessage = By.id("error");
  public void typeusername(String uname) {
	  driver.findElement(username).sendKeys(uname);
  }
  public void typePassword(String PasswordValue) {
	  driver.findElement(Password).sendKeys(PasswordValue);
  }
  public void clickSignIn() {
	  driver.findElement(SignInButton).click();
  }
  public boolean errorMessageDisplay() {
	  boolean errMsgDisplay = driver.findElement(errorMessage).isDisplayed();
	  return errMsgDisplay;
  }
  public String errMessageText() {
	  String errMsg = driver.findElement(errorMessage).getText();
	  return errMsg;
  }
}