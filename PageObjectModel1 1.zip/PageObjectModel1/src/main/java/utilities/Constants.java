package utilities;

public class Constants {
	public static final String Practice_URL = "https://www.tutorialspoint.com/selenium/"+"practice/selenium_automation_practice.php";
	
	public static final String Login_URL = "https://practicetestautomation.com/practice-test-login";
	
	public static final String Username = "student";
	public static final String Password = "Password123";
	
	


}
