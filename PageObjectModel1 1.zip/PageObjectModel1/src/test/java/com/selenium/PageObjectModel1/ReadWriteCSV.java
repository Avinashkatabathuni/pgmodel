package com.selenium.PageObjectModel1;

import java.io.FileReader;
import java.io.IOException;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvValidationException;

public class ReadWriteCSV {
  @Test
  public void csvFile() throws IOException {
	  /*CSVWriter wr1 = new CSVWriter(new FileWriter("C:\\Users\\bandarusri.veera\\selenium-workspace\\PageObjectModel1\\resources1\\NewTestFile.CSV"));
	  String[] rows1 = {"Name","Street"};
	  String[] rows2 = {"Ram","Street 12"};
	  String[] rows3 = {"Rohan","Street 110"};
	  
	  List<String[]> write  = new ArrayList<>();
	  write.add(rows1);
	  write.add(rows2);
	  write.add(rows3);
	  
	  wr1.writeAll(write);
	  wr1.flush(); */
	  
	  CSVReader rd = new CSVReader(new FileReader("C:\\Users\\bandarusri.veera\\selenium-workspace\\PageObjectModel1\\resources1\\NewTestFile.CSV"));
	  String[] csvValues;
	  try {
		  while((csvValues = rd.readNext())!=null) {
			  for(String i:csvValues) {
				  System.out.println(i+" ");
			  }
			  System.out.println();
		  }
	  } catch(CsvValidationException e) {
		  e.printStackTrace();
	  } catch(IOException e) {
		  e.printStackTrace();
	  }

	  

			  
  }
  @BeforeClass
  public void beforeClass() {
  }

  @AfterClass
  public void afterClass() {
  }

}
