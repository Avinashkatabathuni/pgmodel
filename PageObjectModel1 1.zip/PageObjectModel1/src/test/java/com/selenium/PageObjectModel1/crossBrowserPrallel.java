package com.selenium.PageObjectModel1;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class crossBrowserPrallel {
	WebDriver driver;
	
	 @BeforeClass
	 @Parameters({"browser"})
	  public void beforeClass(String br) {
		 if(br.equals("chrome")) {
			 driver = new ChromeDriver();
		 } else if(br.equals("edge")) {
			 driver = new EdgeDriver();
		 }
		 
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		 driver.get("https://www.google.com");
	  }
	 
	 
	 
	 
  @Test
  public void crossBrowserPrallelTest() {
	  System.out.println("test Method");
  }
 

  @AfterClass
  public void afterClass() {
	  driver.quit();
  }

}
