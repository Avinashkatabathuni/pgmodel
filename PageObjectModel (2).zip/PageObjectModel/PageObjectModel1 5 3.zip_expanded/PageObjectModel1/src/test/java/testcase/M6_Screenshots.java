package testcase;
 
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import utilities.Screenshots;
 
public class M6_Screenshots {
	public WebDriver driver;
	@Test(dataProvider = "UserLogin")
		public void TestLogin(String username, String password) {
			WebElement uname = driver.findElement(By.name("username"));
			WebElement pwd = driver.findElement(By.name("password"));
			WebElement submitBtn = driver.findElement(By.id("submit"));
			uname.sendKeys(username);
			pwd.sendKeys(password);
			submitBtn.click();
			String PageTitle = driver.getTitle();
			if(PageTitle.equals("Logged In Successfully | Practice Test Automation")) {
				System.out.println("Logged In Successfully with "+username+" and "+password);
				String msg = driver.findElement(By.tagName("h1")).getText();
				System.out.println(msg+" is displayed");
			}
			else if(PageTitle.equals("Test Login | Practice Test Automation")) {
				WebElement errmsg = driver.findElement(By.id("error"));
				System.out.println("Error message displayed:--"+errmsg.getText()+"\nin page "+PageTitle);
				System.out.println("For credentials "+username+" and "+password);
				String destination = Screenshots.captureScreenshot(driver,username);
				System.out.println(destination);
			}
			else {
				System.out.println("###Invalid page");
			}
		}
		@DataProvider(name = "UserLogin")
		public Object[][] LoginData(){
			return new Object[][] {
				{"Admin", "Password"},
				{"student","NewPassword"},
				{"Robert","Password123"},
				{"",""},
				{"student","Password123"},
			};
		}
		@BeforeTest
		public void Launch() {
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://practicetestautomation.com/practice-test-login/");
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
		}
		@AfterTest
		public void tearDown() {
			driver.quit();
			System.out.println("Test Executed");
		}
}