package testcase;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class M5_DataProvider {
	public WebDriver driver;
  @Test(dataProvider="UserLogin")
  public void TestLogin(String username, String password) {
	  WebElement uname = driver.findElement(By.name("username"));
	  WebElement pwd = driver.findElement(By.name("password"));
	  WebElement submitBtn = driver.findElement(By.id("submit"));
	  uname.sendKeys(username);
	  pwd.sendKeys(password);
	  submitBtn.click();
	  String PageTitle = driver.getTitle();
	  if(PageTitle.equals("Login In Successfully | Practice Test Automation")) {
		  System.out.println("success "+username+" "+password);
		  String msg = driver.findElement(By.tagName("h1")).getText();
		  System.out.println(msg+" is displayed");
	  } else if(PageTitle.equals("Test Login | Practice Test Automation")) {
		  WebElement errormsg = driver.findElement(By.id("error"));
		  System.out.println("Error msg "+errormsg.getText()+"\nin page"+PageTitle);
		  System.out.println("For credentials "+username+" "+password);
		  System.out.println();

	  } else {
		  System.out.println("Invalid Page");
	  }
	  
  }
  
  @DataProvider(name="UserLogin")
  public Object[][] LoginData() {
	  return new Object[][] {
		  {"Admin","Password"},
		  {"student","NewPassword"},
		  {"Robert","Password123"},
		  {"",""},
		  {"student","Password123"},
	  };
  }
  
  
  @BeforeClass
  public void beforeClass() {
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://practicetestautomation.com/practice-test-login/");
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
  }

  @AfterClass
  public void afterClass() {
	  
  }

}
