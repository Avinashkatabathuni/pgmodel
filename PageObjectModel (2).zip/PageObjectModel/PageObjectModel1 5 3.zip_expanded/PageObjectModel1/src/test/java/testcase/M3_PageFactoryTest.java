package testcase;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.PageFactoryLogin;
import Pages.PageFactoryProfile;
import junit.framework.Assert;

public class M3_PageFactoryTest {
	static WebDriver driver;
	
  
  @BeforeClass
  public void beforeClass() {
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://demoqa.com/login");
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(500));
  }
  
  @Test
  public void LoginTest() {
	  PageFactoryLogin loginpg = new PageFactoryLogin(driver);
	  PageFactoryProfile profilepg = new PageFactoryProfile(driver);
	  
	  loginpg.Login_Action("TestNg", "Mercury25*");
	  String actualUser = profilepg.actualUserName();
	  //Assert.assertEquals(actualUser, "TestNg","Username does not match");
	  profilepg.logout_Action();
  }

  @AfterClass
  public void afterClass() {
  }

}
