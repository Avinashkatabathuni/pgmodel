package Pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryProfile {
	final WebDriver driver;

	public PageFactoryProfile(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
		@CacheLookup
		@FindAll({
			@FindBy(className="form-label"),
			@FindBy(id="userName-value")
		})
		WebElement userName;
		
		@FindAll({
			@FindBy(id="submit"),
			@FindBy(tagName="button")
		})
		WebElement logoutBtn;
		
		public void logout_Action() {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("arguments[0].scrollIntoView(true);",logoutBtn);
			logoutBtn.click();
			System.out.println("logout successfull");
		}
		
		public String actualUserName() {
			String uname = userName.getText();
			return uname;
		}
	
	
}
