package utilities;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadDatFromExcel {

	public static void main(String[] args) throws IOException {
		FileInputStream file = new FileInputStream("C:\\Users\\nkrishna.chowd\\selenium_workspace\\PageObjectModel1 1\\PageObjectModel1\\resources1\\books_with_data.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet("Sheet1");
		int totalRows = sheet.getLastRowNum();
		int totalCells = sheet.getRow(1).getLastCellNum();
		System.out.println("no of rows: "+totalRows);//start from 0
		System.out.println("no of cells: "+totalCells);//start from 1
		
		for(int r = 0;r<=totalRows;r++) {
			XSSFRow currRow = sheet.getRow(r);
			for(int c = 0;c<totalCells;c++) {
				XSSFCell cell = currRow.getCell(c);
				System.out.print(cell+"\t\t");
			}
			System.out.println();
		}
		workbook.close();
		file.close();
		
	}

}
