package utilities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReadcsvData {
	public Object[][] ReadValueCsv(String csvFilePath) throws IOException {
		
		BufferedReader br = null;
		String line = "";
		String csvDelimiter = ",";
		
		List<Object[]> data = new ArrayList<>();
		
		try {
			br = new BufferedReader(new FileReader(csvFilePath));
			while((line=br.readLine())!=null) {
				String[] rowData = line.split(csvDelimiter);
				data.add(rowData);
			}
		} finally {
			if(br!=null) {
				br.close();
			}
		}
		return data.toArray(new Object[0][]);
	}
}
