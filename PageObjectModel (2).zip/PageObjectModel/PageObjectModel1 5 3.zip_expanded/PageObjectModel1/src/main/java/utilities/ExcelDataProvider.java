package utilities;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.DataProvider;

public class ExcelDataProvider {
	@DataProvider(name="excelData")
	public Object[][] excelDataProvder() {
		Object[][] arrObj = getExcelData("C:\\Users\\nkrishna.chowd\\selenium_workspace\\PageObjectModel1 1\\PageObjectModel1\\resources1\\search.xlsx","Sheet1");
		return arrObj;
	}

	private String[][] getExcelData(String fileName, String sheetName) {
		String[][] data = null;
		try {
			FileInputStream fis = new FileInputStream(fileName);
			try(XSSFWorkbook workbook = new XSSFWorkbook(fis)) {
				XSSFSheet sheet = workbook.getSheet(sheetName);
				XSSFRow row = sheet.getRow(0);
				int noOfRows = sheet.getPhysicalNumberOfRows();
				int noOfCols = sheet.getLastRowNum();
				Cell cell;
				data = new String[noOfRows-1][noOfCols-1];
				
				for(int i = 1;i<noOfRows;i++) {
					for(int j = 0;j<noOfCols;j++) {
						row = sheet.getRow(i);
						cell = row.getCell(j);
						data[i-1][j] = cell.getStringCellValue();
					}
				}
			}
		} catch (Exception e) {
			System.out.println("Exception "+e.getMessage());
		}
		return data;
	}

}
