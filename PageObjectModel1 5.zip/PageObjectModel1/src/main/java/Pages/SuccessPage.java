package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SuccessPage {
	private WebDriver driver;
	  public  SuccessPage(WebDriver driver) {
		  this.driver = driver;
	  }
	  By msg = By.xpath("//*[@id=\"loop-container\"]/div/article/div[2]/p[1]/strong");
	  public boolean loginMessageDisplayed() {
		  return driver.findElement(msg).isDisplayed();
	  }

}
