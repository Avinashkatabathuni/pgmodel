package utilities;
 
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
 
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;
 
public class Screenshots {
	public static String takeScreenshotAtEndOfTest(WebDriver driver,String screenshotName) throws IOException {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		TakesScreenshot ts = (TakesScreenshot)driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		//String destination = System.getProperty("user.dir") + "/screenshots/" + dateName + ".png";
		String destination = "C:\\Users\\nkrishna.chowd\\selenium_workspace\\PageObjectModel1 1\\PageObjectModel1\\src\\main\\resources\\screenshots"+screenshotName+"_"+dateName+".png";
		File finalDestination = new File(destination);
		FileHandler.copy(source, finalDestination);
		return destination;
	}
	public static String captureScreenshot(WebDriver driver,String screenshotName) {
		//generate timestamp
		String timestamp = new SimpleDateFormat("yyyyMMd_HHmmss").format(new Date());
		//convert WebDriver object to TakesScreenshot
		TakesScreenshot ts = (TakesScreenshot) driver;
		//capture screenshot as File object
		File source = ts.getScreenshotAs(OutputType.FILE);
		//define destination path
		String destination = "C:\\Users\\nkrishna.chowd\\selenium_workspace\\PageObjectModel1 1\\PageObjectModel1\\src\\main\\resources\\screenshots"+screenshotName+"_"+timestamp+".png";
		//Screenshots/Googletest_2024208_077264.png
		try {
			//copy file to destination
			FileUtils.copyFile(source, new File(destination));
			System.out.println("Screenshot captured and saved to: "+destination);
		}catch(IOException e) {
			System.out.println("Failed to capture screenshot: "+e.getMessage());
		}
		return destination;
	}
}