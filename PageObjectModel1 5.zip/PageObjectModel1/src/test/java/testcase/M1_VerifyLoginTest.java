package testcase;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Pages.LoginPage;
 
public class M1_VerifyLoginTest {
	
	private WebDriver driver;
	
	@BeforeMethod
	public void setup() {
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\bandarusri.veera\\selenium-workspace\\resources\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://practicetestautomation.com/practice-test-login/");
	}
	
  @Test
  public void testSucessfullLogin() {
//	  Creating LoginPage object and passing driver instance as parameter to constructor of Loginpage
	  LoginPage loginPage= new LoginPage(driver);
	  
//	  Type username
	  loginPage.typeusername("student");
	  
//	  Type Password value
	  loginPage.typePassword("Password123");
	  
//	  Click on SignIn Button
	  loginPage.clickSignIn();
	    
  }
  
  @AfterMethod
  public void teardown() {
	  if(driver!=null) {
//		  driver.quit();
	  }
  }
}