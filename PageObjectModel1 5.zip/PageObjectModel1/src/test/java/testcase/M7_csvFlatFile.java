package testcase;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;

public class M7_csvFlatFile {
	String csvFilePath = "./resources1/LoginDetails.CSV"; // CSV file path
 
@Test 
public void CSVReadWrite() throws InterruptedException, IOException, CsvValidationException { 
 
	try (CSVWriter writeFile = new CSVWriter(new FileWriter(csvFilePath))) {
 
	//stores values in csv
	 
	String[] row1 =  { "UserName", "Password"};
	String[] row2 = {"Atul", "Password"};
	String[] row3 = {"Rohan",""};
	String[] row4 = {"", "student"};
	String[] row5 = {"Admin", "Admin"};
	String[] row6 = {"student", "Password123"};
 
	List<String[]> writelist = new ArrayList<>();
	writelist.add(row1);
	writelist.add(row2);
	writelist.add(row3);
	writelist.add(row4);
	writelist.add(row5);
	writelist.add(row6);
 
	//write and flush all values
	 
	writeFile.writeAll(writelist);
	 
	writeFile.flush();
}

/*CsvValidationException is used to read from csv File
use in try catch or method declaration
handles enrors like delimiter mismatch, incorrect data format, etc*/
	
	
		// Read from CSV File
		//Object of CSVReader class
		try (CSVReader readerFile = new CSVReader(new FileReader(csvFilePath))) {
			String[] csvValues;
			while ((csvValues = readerFile.readNext()) != null) {
			//iterate through rows
			 
				for (String csvValue: csvValues)
					System.out.print(csvValue+" ");
				System.out.println();
			}
			System.out.println("executed");
		}
	}
}