package testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import utilities.ExcelDataProvider;

public class M11_ExcelDataProvider {
  WebDriver driver;
  @BeforeClass
  public void beforeClass() {
	  System.out.println("Start test");
	  driver = new ChromeDriver();
	  driver.get("https://www.google.com");
	  driver.manage().window().maximize();
  }
  @Test(dataProvider = "excelData",dataProviderClass = ExcelDataProvider.class)
  public void search(String keyWord1, String keyWord2) {
	  WebElement txtBox = driver.findElement(By.name("q"));
	  txtBox.sendKeys(keyWord1," ",keyWord2);
	  System.out.println("keyWord entered "+keyWord1+" "+keyWord2);
	  txtBox.sendKeys(Keys.ENTER);
	  System.out.println("search results are displayed");
	  System.out.println("result: "+driver.getTitle());
	  Assert.assertTrue(driver.getPageSource().contains(keyWord1));
  }
  @AfterClass
  public void afterClass() {
  }

}
