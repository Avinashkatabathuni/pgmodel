package testcase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Pages.LoginPage;
import Pages.SuccessPage;
import junit.framework.Assert;
import utilities.Constants;

public class M2_LoginConstantsTest {
  private WebDriver driver;
  @BeforeClass
  public void beforeClass() {
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get(Constants.Login_URL);
  }
  
  
  @Test
  public void testSuccessfullLogin() {
	  LoginPage loginPage = new LoginPage(driver);
	  
	  loginPage.typeusername(Constants.Username);
	  loginPage.typePassword(Constants.Password);
	  loginPage.clickSignIn();
	  
	  SuccessPage searchPage = new SuccessPage(driver);
	  Assert.assertTrue(searchPage.loginMessageDisplayed());
  }
  @AfterClass
  public void afterClass() {
  }

}
