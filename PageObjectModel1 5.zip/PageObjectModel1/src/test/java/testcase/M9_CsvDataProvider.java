package testcase;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pages.LoginPage;
import utilities.Constants;
import utilities.ReadcsvData;

public class M9_CsvDataProvider {
	WebDriver driver;
	
	String csvFilePath = "./resources1/LoginDetails.CSV";
	
	@DataProvider(name = "csvData")
	public Object[][] provideData() throws IOException {
		ReadcsvData read = new ReadcsvData();
		Object[][] data = read.ReadValueCsv(csvFilePath);
		System.out.println(data);
		return data;
		
	}
	
	
  @BeforeClass
  public void beforeClass() {
	  driver = new ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get(Constants.Login_URL);
  }
  @Test(dataProvider="csvData")
  public void testcase1(String username,String password) throws InterruptedException {
	  LoginPage loginPage = new LoginPage(driver);
	  loginPage.typeusername(username);
	  loginPage.typePassword(password);
	  Thread.sleep(3000);
	  loginPage.clickSignIn();
	  
  }

  @AfterClass
  public void afterClass() {
	  
  }

}
