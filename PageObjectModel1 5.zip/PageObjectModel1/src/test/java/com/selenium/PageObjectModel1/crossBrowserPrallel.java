package com.selenium.PageObjectModel1;
 
import java.time.Duration;
 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.*;
 
import io.github.bonigarcia.wdm.WebDriverManager;
 
public class crossBrowserPrallel {
 
    // Thread-safe driver for parallel execution
    private static final ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();
 
    public static WebDriver getDriver() {
        return tlDriver.get();
    }
 
    @BeforeClass
    @Parameters({"browser"})
    public void beforeClass(@Optional("edge") String br) {
        WebDriver driver;
        switch (br.toLowerCase()) {
            case "chrome":
                WebDriverManager.chromedriver().setup();
                driver = new ChromeDriver();
                break;
            case "edge":
                WebDriverManager.edgedriver().setup();
                driver = new EdgeDriver();
                break;
            default:
                throw new IllegalArgumentException("Unsupported browser: " + br);
        }
 
        tlDriver.set(driver);
 
        // Basic setup
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.manage().window().maximize();
        driver.get("https://www.google.com");
    }
 
    @Test
    public void crossBrowserParallelTest() {
        System.out.println("Test method on thread: " + Thread.currentThread().getId());
        WebDriver driver = getDriver();
        System.out.println("Title: " + driver.getTitle());
        // Add assertions if you want:
        // Assert.assertTrue(driver.getTitle().contains("Google"));
    }
 
    @AfterClass(alwaysRun = true)
    public void afterClass() {
        WebDriver driver = getDriver();
        if (driver != null) {
            driver.quit();
            tlDriver.remove();
        }
    }
}